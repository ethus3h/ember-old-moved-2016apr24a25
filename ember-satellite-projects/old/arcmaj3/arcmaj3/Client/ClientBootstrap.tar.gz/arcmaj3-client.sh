#!/bin/bash
./arcmaj3-update.sh;
cd ./amc/amI1;
python ./start.py;