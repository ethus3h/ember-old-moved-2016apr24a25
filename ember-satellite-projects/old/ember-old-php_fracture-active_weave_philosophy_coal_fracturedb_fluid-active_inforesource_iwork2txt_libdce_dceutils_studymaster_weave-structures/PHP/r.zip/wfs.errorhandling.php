<?php
//Handle errors
include('d/r/wf.err.php');
//Handle 'unrecognised action' errors
include('d/r/wf.unrecognisedAction.php');
?>
