<?php
//Begin a form
function beginForm($caption)
{
    return $caption . itr(1242);
}
?>
