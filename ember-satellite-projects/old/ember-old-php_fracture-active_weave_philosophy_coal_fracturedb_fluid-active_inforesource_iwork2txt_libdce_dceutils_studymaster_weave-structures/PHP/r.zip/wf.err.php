<?php
function err($errId)
{
    global $error;
    $error = $errId;
}
?>
