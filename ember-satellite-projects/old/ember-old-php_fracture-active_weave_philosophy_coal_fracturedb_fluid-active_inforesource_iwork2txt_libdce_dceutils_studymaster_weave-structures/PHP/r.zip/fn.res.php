<?php
function res($name)
{
    global $dataDirectory;
    return file_get_contents($dataDirectory . $name);
}
?>
