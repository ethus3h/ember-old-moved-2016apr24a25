<?php
//WEAVE
include ('d/r/w.setup.php');
//Database connection
include ('d/r/w.dbconnect.php');
//Function definitions
include ('d/r/w.functions.php');
//Classes
include ('d/r/w.classes.php');
//Page parameter definitions
include ('d/r/w.pageparams.php');
//Action approval
include ('d/r/w.actionapproval.php');
//Action definitions
include ('d/r/w.actions.php');
//Render page
include ('d/r/w.render-page.php');
?>
