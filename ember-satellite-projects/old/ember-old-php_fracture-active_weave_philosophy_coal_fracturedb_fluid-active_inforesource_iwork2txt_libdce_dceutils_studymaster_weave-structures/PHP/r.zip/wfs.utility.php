<?php
//Utility functions
//explode_escaped (not written by me)
include('d/r/wf.explode_escaped.php');
//Return an escaped array (not written by me)
include('d/r/wf.mysql_real_escape_array.php');
?>
