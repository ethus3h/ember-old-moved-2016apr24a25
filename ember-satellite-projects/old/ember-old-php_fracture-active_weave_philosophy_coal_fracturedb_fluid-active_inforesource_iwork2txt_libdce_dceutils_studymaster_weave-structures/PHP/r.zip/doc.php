<?php
//DOC: What to change for the new version
/* 1. futuramerlincom.fatcow.com 2. futuramerlin.com 3. futuramerlin.
 All of these need to be changed in other files too. */
?>
