<?php
//FUNCTIONS
include('d/r/fn.res.php');
include('d/r/fn.e.php');
?>
