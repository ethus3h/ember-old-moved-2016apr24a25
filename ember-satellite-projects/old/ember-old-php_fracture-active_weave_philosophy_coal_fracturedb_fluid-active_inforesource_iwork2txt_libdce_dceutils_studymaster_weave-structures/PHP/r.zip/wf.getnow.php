<?php
function getnow()
{
    //TODO
    return '2012';
}
?>
