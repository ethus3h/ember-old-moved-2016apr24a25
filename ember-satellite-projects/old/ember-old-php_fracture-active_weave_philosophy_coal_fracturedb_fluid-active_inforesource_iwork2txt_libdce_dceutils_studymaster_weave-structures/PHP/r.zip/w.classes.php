<?php
#GENERAL CLASSES
#Properties: text
include ('d/r/wc.text.php');
#Properties: long text
include ('d/r/wc.longtext.php');
#Properties: number
include ('d/r/wc.number.php');
#Properties: reference
include ('d/r/wc.reference.php');
#Properties: Boolean
include ('d/r/wc.boolean.php');
#Properties: data
include ('d/r/wc.data.php');
include ('d/r/wc.datarev.php');
include ('d/r/wc.datatype.php');

#GENERAL RECORD TYPES
#Interface fragments
include ('d/r/wc.intf.php');
#Locales
include ('d/r/wc.locale.php');
#Characters
include ('d/r/wc.character.php');
#Character categories
include ('d/r/wc.charcat.php');
#Scripts
include ('d/r/wc.script.php');
#Dates and times
include ('d/r/wc.datetime.php');
#Users
include ('d/r/wc.user.php');

#ABSTRACT RECORD TYPES
#Nodes
include ('d/r/wc.node.php');
include ('d/r/wc.noderev.php');
include ('d/r/wc.nodetype.php');
#Relationships
include ('d/r/wc.rel.php');
include ('d/r/wc.relrev.php');
include ('d/r/wc.reltype.php');
#Metadata
include ('d/r/wc.meta.php');
?>
