<?php
//Print a specified localised string from the database.
function itf($itfid)
{
    e(itr($itfid));
}
?>
