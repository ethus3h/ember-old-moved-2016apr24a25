<?php
//Form handling
include('d/r/wf.beginForm.php');
include('d/r/wf.finishForm.php');
//Make a hyperlink or formlink
include('d/r/wf.buildLink.php');
?>
