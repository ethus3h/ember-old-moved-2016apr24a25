<?php
function e($content)
{
    global $websiteName;
    global $cssFile;
    global $serverUrl;
    global $pageClass;
    if ($pageClass == 'w') {
        $tbl = '';
    } else {
        $tbl = '<table border="0" cellpadding="24" width="100%"><tbody><tr><td><br><h1>';
    }
    $univNeedles = array('href="' . $serverUrl, "\t", "\n", "\r", "  ", "  ", "  ", "> <", '@p1@', '@p2@', '@p3@', '@p4@', '@cssFile@', '@websiteName@', '@tbl@', '@l@', '@n@', 'https://futuramerlincom.fatcow.com',);
    $univHaystacks = array('href="', " ", " ", " ", " ", " ", " ", '><', res('1.d'), res('2.d'), res('3.d'), res('4.d'), $cssFile, $websiteName, $tbl, '<a href="r.php?', '">', 'http://localhost',);
    echo trim(str_replace($univNeedles, $univHaystacks, $content));
}

?>
