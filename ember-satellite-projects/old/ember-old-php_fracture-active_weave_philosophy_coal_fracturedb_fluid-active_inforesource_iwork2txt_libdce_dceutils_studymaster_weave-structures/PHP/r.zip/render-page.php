<?php
        //This is a normal webpage
        if ($pageClass) {
            $pageLoc = 'p/' . $pageClass . '/' . $pageAction . '.p';
        } else {
            $pageLoc = 'p/' . $pageAction . '.p';
        }
        e(res($pageLoc));
?>
