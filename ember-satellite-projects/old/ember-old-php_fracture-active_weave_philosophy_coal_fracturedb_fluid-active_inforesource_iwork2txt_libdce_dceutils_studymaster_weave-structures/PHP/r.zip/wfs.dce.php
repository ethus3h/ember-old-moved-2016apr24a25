<?php
//Parse a supplied CDCE string and return it as HTML
include('d/r/wf.c.php');
//Return the time as a DCE string
include('d/r/wf.getnow.php');
?>
