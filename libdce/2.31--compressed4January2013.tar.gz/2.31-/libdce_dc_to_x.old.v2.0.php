<?php
/*libdce: convert Dc to x. Version 2.0, 31 December 2012 (first independent version).
*/
function convert_dc_to_dc_output($data){
return $data;
}

