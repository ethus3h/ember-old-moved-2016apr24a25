<?php
/*libdce: convert Dc to x. Version 2.1, 1 January 2012 (after midnight of 31 December 2012).
*/
function convert_dc_to_dc_output($data){
return $data;
}

