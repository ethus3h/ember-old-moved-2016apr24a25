<?php 
/*libdce redirection script, version 2.4 (first version), 3 January 2013.*/
header('Location: 2.4/libdce.php');
?>
