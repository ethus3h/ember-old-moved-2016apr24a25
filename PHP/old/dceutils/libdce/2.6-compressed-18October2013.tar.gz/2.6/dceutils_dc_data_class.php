<?php
//Dc_Data class for manipulating raw Dc data
class Dc_Data
{
}
?>
