package com.futuramerlin.ember.Client.StdioClient;

/**
 * Created by elliot on 14.10.29.
 */
public class StdioClient {
    public static void main() {

    }
    public void sayHello() {
        System.out.println("Hello!");
    }
}
